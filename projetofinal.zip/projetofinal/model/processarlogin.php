<?php 
    include_once "../factory/conexao.php"; //trazer a conexao pro arquivo
    SESSION_START(); //ABRIR UM ESPAÇO TEMPORÁRIO NA NUVEM

    $login = $_POST["cxlogin"];
    $senha = $_POST["cxsenha"];
    $sql = "select * from usuarios WHERE 
    email = '$login' AND senha = '$senha'";
    $result = mysqli_query($connect, $sql);
    $linha = mysqli_fetch_array($result);
    if(mysqli_num_rows($result) > 0){
        if($linha['perfil']=="Professor"){
            header("location:../view/professor.php");
        }else if($linha['perfil']=="Aluno"){
            header("location:../view/aluno.php");
        }else if($linha['perfil']=="Diretor"){
            header("location:../view/diretor.php");
        }
    }
?>
