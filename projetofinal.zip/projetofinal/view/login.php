<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Alata&family=Alexandria:wght@100..900&family=Staatliches&display=swap" rel="stylesheet">
    <title>Tela de Login</title>
</head>
<body>
    <div id="design">
    <h3>Gossip Girl</h3>
        <img src="../imagens/gossipgirl.png" alt="Logo da Serie Gossip Girl" style="width: 900px;
    height: 220px; position: relative;">
    </div>
    <div id="login">
        <form action="../model/processarlogin.php" method="POST">
        <h2>Login</h2><br>
        <div id="linha"> <h4></h4></div>
            Usuário: <br>
            <input type="text" name="cxlogin"><br><br>
            Senha: <br>
            <input type="password" name="cxsenha"><br><br>
            <input type="submit" id="acesso" value="Acessar">
            <h5><a href="#">Esqueci minha senha</a></h5>
        </form>

    </div>
</body>
</html>