<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Alata&family=Alexandria:wght@100..900&family=Staatliches&display=swap" rel="stylesheet">
    <title>Aluno</title>
</head>
<style> 
     *{
        background-color: #1E1B1F;
        margin: 0;
        font-family: "Alexandria", sans-serif;
        }

        img{
        background-color: #DEAE5D;
          margin: auto;
          padding: 20px;
        }

         #design {
           margin: 0 auto;
           text-align: center;
            background-color: #A36A23;
}

h3{
    background-color: transparent;
    color: white;
    padding-bottom: 15px;
}

</style>
<body>
    <div id="design">
            <img src="../imagens/gossipgirl.png" alt="Logo da Universidade de Harvard" style="width: 200px;
        height: 180px; position: relative;">
        <h3>Menu Aluno</h3>
    </div>
</body>
</html>