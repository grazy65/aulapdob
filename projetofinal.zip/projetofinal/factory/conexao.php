<?php
   $server = "localhost";
   $user = "root";
   $senha = "";
   $banco  = "usuarios";
   $connect=mysqli_connect($server,$user,$senha,$banco);

?>
